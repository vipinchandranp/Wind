package hibernate.util;


public enum JoinType {

	FETCH, JOIN;
}
